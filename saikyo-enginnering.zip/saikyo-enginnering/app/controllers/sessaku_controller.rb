class SessakuController < ApplicationController
  def index
  end
end
