module SokuryouHelper
end
