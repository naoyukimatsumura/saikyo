class SummaryController < ApplicationController
  def index
  end
end
