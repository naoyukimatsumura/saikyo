module HosouHelper
end
