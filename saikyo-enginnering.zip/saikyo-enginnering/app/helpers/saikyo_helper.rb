module SaikyoHelper
end
