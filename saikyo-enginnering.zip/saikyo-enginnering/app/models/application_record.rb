class ApplicationRecord < ActiveRecord::Base
  self.abstract_class = true
end

class Post < ActiveRecord::Base
  mount_uploader :image, ImageUploader
end