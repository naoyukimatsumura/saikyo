Rails.application.routes.draw do
   
  
  
    root to: 'saikyo#index'
    
  get 'summary', to: 'summary#index'
  get 'sessaku', to: 'sessaku#index'
  get 'hosou', to: 'hosou#index'
  get 'sokuryou',to: 'sokuryou#index'
  get 'seisou',to: 'romen#index'
  get 'sessakuki',to: 'sessakuki#index'
  get 'contact',to: 'contact#index'
    
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
