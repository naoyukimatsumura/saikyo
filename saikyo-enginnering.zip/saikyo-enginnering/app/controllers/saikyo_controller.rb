class SaikyoController < ApplicationController
  def index
  end
end
