class SokuryouController < ApplicationController
  def index
  end
end
