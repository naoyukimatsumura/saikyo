class HosouController < ApplicationController
  def index
  end
end
