class RomenController < ApplicationController
  def index
  end
end
