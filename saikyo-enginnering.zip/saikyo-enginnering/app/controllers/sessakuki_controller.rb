class SessakukiController < ApplicationController
  def index
  end
end
